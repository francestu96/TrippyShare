Esercizio: Controllo dell'input lato server
L'esercizio l'abbiamo fatto sul form di registrazione nella pagina login.php
In particolare i nostri controlli sono stati sul passaggio reale dei parametri, e sull'autenticità del codice fiscale.
Ovviamente non avendo un database non registriamo i dati dell'utente.

Esercizio: Login
I dati di login sono presenti nel file myusers.txt. 
L'esercizio è sul form di login nella pagina login.php.
In caso di corretto login rimandiamo l'utente nella home page (index.php) e apparirà il nome dell'utente in alto a destra.
Utilizziamo come "tecnologia" di login le sessioni.



Bonus: 
Abbiamo utilizzato i require("common/footer.php"); per riciclare il codice. Vedi qui: http://php.net/manual/en/function.require.php
Molti tra i file nella cartella assets sono per il template del nostro sito, utili per la parte grafica e non per questa esercitazione.
